from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
import pandas as pd
import os
from fpdf import FPDF

router = APIRouter()
UPLOAD_DIR = "uploads"
ACTIVE_FILE = os.path.join(UPLOAD_DIR, "active_dataset.csv")
EXCEL_PATH = os.path.join(UPLOAD_DIR, "report.xlsx")
PDF_PATH = os.path.join(UPLOAD_DIR, "report.pdf")

@router.get("/export-excel")
async def export_excel():
    if not os.path.exists(ACTIVE_FILE):
        raise HTTPException(status_code=404, detail="Upload a dataset first.")
    try:
        df = pd.read_csv(ACTIVE_FILE)
        df.to_excel(EXCEL_PATH, index=False, engine='openpyxl')
        return FileResponse(EXCEL_PATH, filename="Forecast_Report.xlsx")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/export-pdf")
async def export_pdf():
    if not os.path.exists(ACTIVE_FILE):
        raise HTTPException(status_code=404, detail="Upload a dataset first.")

    try:
        # 1. Load the data
        df = pd.read_csv(ACTIVE_FILE).head(20) # Limit to top 20 for PDF preview
        
        # 2. Initialize PDF
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)
        pdf.cell(190, 10, "AI Demand Forecasting - Data Summary", ln=True, align='C')
        pdf.ln(10)

        # 3. Add Table Headers
        pdf.set_font("Arial", "B", 10)
        cols = df.columns.tolist()
        col_width = 190 / len(cols)
        for col in cols:
            pdf.cell(col_width, 10, str(col), border=1)
        pdf.ln()

        # 4. Add Table Rows
        pdf.set_font("Arial", "", 10)
        for _, row in df.iterrows():
            for val in row:
                pdf.cell(col_width, 10, str(val), border=1)
            pdf.ln()

        # 5. Save and Return
        pdf.output(PDF_PATH)
        return FileResponse(
            path=PDF_PATH, 
            filename="AI_Demand_Report.pdf",
            media_type='application/pdf'
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF Generation failed: {str(e)}")