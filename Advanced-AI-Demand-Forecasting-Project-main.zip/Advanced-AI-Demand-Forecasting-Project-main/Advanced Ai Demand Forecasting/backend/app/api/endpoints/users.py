from fastapi import APIRouter, Depends
from app.api.deps import get_current_user

router = APIRouter()

@router.get("/me")
async def get_user_me(current_user: str = Depends(get_current_user)):
    return {"user": current_user, "message": "User profile data"}