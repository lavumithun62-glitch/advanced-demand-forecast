import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { LayoutGrid, UploadCloud, TrendingUp, BarChart3, LogOut } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Dataset from './pages/Dataset';
import Forecast from './pages/Forecast';
import Reports from './pages/Reports';
import Login from './pages/Login';

const Sidebar = () => {
  const location = useLocation();
  const menu = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutGrid },
    { name: 'Upload Dataset', path: '/dataset', icon: UploadCloud },
    { name: 'Forecast', path: '/forecast', icon: TrendingUp },
    { name: 'Reports', path: '/reports', icon: BarChart3 },
  ];

  return (
    <aside className="w-64 fixed inset-y-0 bg-[#0b0e14] border-r border-slate-800 flex flex-col p-4 z-50">
      <div className="mb-10 px-4 py-2">
        <h1 className="text-white text-xl font-bold tracking-tight">AI Forecast</h1>
        <div className="h-1 w-8 bg-blue-600 mt-1 rounded-full"></div>
      </div>
      <nav className="flex-1 space-y-1">
        {menu.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              location.pathname === item.path 
              ? 'bg-[#1e293b] text-blue-500 border-r-2 border-blue-500' 
              : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
            }`}
          >
            <item.icon size={18} /> {item.name}
          </Link>
        ))}
      </nav>
      <button 
        onClick={() => { localStorage.clear(); window.location.href = '/login'; }}
        className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-400 text-sm font-medium transition-colors bg-[#1a1114] rounded-lg mt-auto"
      >
        <LogOut size={18} /> Logout
      </button>
    </aside>
  );
};

export default function App() {
  const auth = !!localStorage.getItem('token');
  return (
    <Router>
      <div className="flex bg-brand-bg min-h-screen text-slate-200">
        {auth && <Sidebar />}
        <main className={auth ? "flex-1 ml-64" : "flex-1"}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={auth ? <Dashboard /> : <Navigate to="/login" />} />
            <Route path="/dataset" element={auth ? <Dataset /> : <Navigate to="/login" />} />
            <Route path="/forecast" element={auth ? <Forecast /> : <Navigate to="/login" />} /> 
            <Route path="/reports" element={auth ? <Reports /> : <Navigate to="/login" />} />
            <Route path="*" element={<Navigate to="/dashboard" />} />
            <Route path="/forecast" element={<Forecast />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}