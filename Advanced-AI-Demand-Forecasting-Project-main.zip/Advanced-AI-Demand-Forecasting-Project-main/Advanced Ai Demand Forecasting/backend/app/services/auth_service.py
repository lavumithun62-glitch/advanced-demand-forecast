from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext
from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

# Mock DB Logic (Replace with your SQLAlchemy code)
def register_new_user(user_in):
    hashed_pw = get_password_hash(user_in.password)
    # save_to_db(user_in.email, hashed_pw)
    return user_in

def authenticate_user(email, password):
    # user = get_user_from_db(email)
    # if user and verify_password(password, user.password):
    #     return user
    return None