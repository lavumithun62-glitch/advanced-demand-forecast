from pydantic import BaseModel, EmailStr
from typing import Optional

# Matches the "UserCreate" schema in your image
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str

# Matches the "Body_login_auth_login_post"
class Token(BaseModel):
    access_token: str
    token_type: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr

    class Config:
        from_attributes = True