from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, EmailStr
from app.core.security import SecurityHandler

router = APIRouter()

# This is temporary. If you restart the server, you must register again.
users_db = {} 

# Pydantic Schemas to fix the 422 Error
class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserRegister(UserLogin):
    full_name: str

@router.post("/register")
async def register(user: UserRegister):
    if user.email in users_db:
        raise HTTPException(status_code=400, detail="User already exists")
    
    hashed_pwd = SecurityHandler.hash_password(user.password)
    users_db[user.email] = {
        "full_name": user.full_name,
        "password": hashed_pwd
    }
    return {"message": "User registered successfully. You can now login."}

@router.post("/login")
async def login(user: UserLogin):
    db_user = users_db.get(user.email)
    
    if not db_user:
        raise HTTPException(status_code=401, detail="User not found. Please register first.")

    if not SecurityHandler.verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Incorrect password")

    token = SecurityHandler.create_access_token(data={"sub": user.email})
    return {
        "access_token": token, 
        "token_type": "bearer",
        "user": {"name": db_user["full_name"], "email": user.email}
    }