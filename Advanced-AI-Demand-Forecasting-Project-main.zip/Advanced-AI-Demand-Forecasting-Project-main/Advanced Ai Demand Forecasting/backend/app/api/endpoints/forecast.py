import os
import pandas as pd
from fastapi import APIRouter, HTTPException
from prophet import Prophet
from datetime import datetime

router = APIRouter()

# Path to the dataset uploaded via the Dataset Module
UPLOAD_DIR = "uploads"
DATASET_PATH = os.path.join(UPLOAD_DIR, "active_dataset.csv")

@router.get("/predict")
async def generate_forecast():
    # 1. Check if dataset exists
    if not os.path.exists(DATASET_PATH):
        raise HTTPException(status_code=400, detail="Dataset not found. Please upload a CSV first.")

    try:
        # --- TASK 1: PREPROCESS DATASETS USING PANDAS ---
        df = pd.read_csv(DATASET_PATH)
        
        # Standardize column names (lowercase & stripped)
        df.columns = df.columns.str.strip().str.lower()

        # Identify date and target columns dynamically
        date_col = next((c for c in df.columns if 'date' in c or 'month' in c), None)
        target_col = next((c for c in df.columns if 'revenue' in c or 'sales' in c or 'amount' in c), None)

        if not date_col or not target_col:
            raise HTTPException(status_code=422, detail="CSV must contain 'Date' and 'Revenue/Sales' columns.")

        # Data Cleaning
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        df[target_col] = pd.to_numeric(df[target_col], errors='coerce')
        df = df.dropna(subset=[date_col, target_col])

        # Prophet requirements: columns must be named 'ds' and 'y'
        prophet_df = df[[date_col, target_col]].rename(columns={date_col: 'ds', target_col: 'y'})
        
        # Aggregate to daily/monthly sum to handle duplicate dates
        prophet_df = prophet_df.groupby('ds').sum().reset_index()

        # --- TASK 2: TRAIN FORECASTING MODEL (PROPHET) ---
        model = Prophet(
            yearly_seasonality=True, 
            weekly_seasonality=False, 
            daily_seasonality=False
        )
        model.fit(prophet_df)

        # --- TASK 3: GENERATE FUTURE DEMAND PREDICTIONS ---
        # Creating a dataframe for the next 6 months
        future = model.make_future_dataframe(periods=6, freq='MS')
        forecast = model.predict(future)

        # --- TASK 4: DEVELOP APIs FOR PREDICTION RESULTS ---
        # Extract only the future predictions (the tail)
        predictions = forecast[['ds', 'yhat']].tail(6)
        
        formatted_results = []
        for _, row in predictions.iterrows():
            formatted_results.append({
                "month": row['ds'].strftime('%Y-%m'),
                "predicted_revenue": f"₹ {max(0, round(row['yhat'], 2)):,}"
            })

        return {
            "status": "success",
            "model_used": "Prophet AI",
            "data": formatted_results
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Forecasting Error: {str(e)}")