import React, { useState } from 'react';
import axios from 'axios';
import { UploadCloud, CheckCircle, AlertCircle } from 'lucide-react';

export default function Dataset() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle');

  const handleUpload = async () => {
    if (!file) return;
    setStatus('uploading');
    const formData = new FormData();
    formData.append('file', file); // "file" must match backend UploadFile name

    try {
      await axios.post('http://127.0.0.1:8000/analytics/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setStatus('success');
    } catch (err) {
      setStatus('error');
    }
  };

  return (
    <div className="p-10 ml-64 min-h-screen bg-brand-bg text-white">
      <h1 className="text-3xl font-bold mb-8 text-white">Upload Dataset</h1>
      <div className="bg-brand-card border-2 border-dashed border-slate-800 rounded-3xl p-20 flex flex-col items-center">
        <div className="bg-blue-600/10 p-6 rounded-full mb-6 text-blue-500"><UploadCloud size={48} /></div>
        <p className="text-slate-400 mb-6">Drag & Drop Dataset or click below</p>
        
        <input type="file" id="upload" className="hidden" onChange={(e) => setFile(e.target.files[0])} />
        <label htmlFor="upload" className="bg-blue-600 px-10 py-3 rounded-xl font-bold cursor-pointer hover:bg-blue-500 transition-all">
          {file ? file.name : "Select CSV File"}
        </label>

        {file && status !== 'success' && (
          <button onClick={handleUpload} className="mt-6 text-blue-400 font-bold underline">
            {status === 'uploading' ? 'Processing...' : 'Confirm Upload'}
          </button>
        )}

        {status === 'success' && (
          <div className="mt-8 flex items-center gap-2 text-emerald-400 bg-emerald-500/10 px-6 py-3 rounded-xl border border-emerald-500/20">
            <CheckCircle size={20} /> Dataset uploaded successfully!
          </div>
        )}
      </div>
    </div>
  );
}