import React, { useState } from 'react';
import axios from 'axios';

export default function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    full_name: '' // Mandatory to match your backend model
  });
  const [isRegistering, setIsRegistering] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const endpoint = isRegistering ? 'register' : 'login';
    
    // We send full_name even for login to avoid backend validation errors
    const payload = {
      email: formData.email,
      password: formData.password,
      full_name: isRegistering ? formData.full_name : "User" 
    };

    try {
      const res = await axios.post(`http://127.0.0.1:8000/auth/${endpoint}`, payload);

      if (isRegistering) {
        alert("Success! Account created. Now click Login.");
        setIsRegistering(false);
      } else {
        localStorage.setItem('token', res.data.access_token);
        window.location.href = '/dashboard';
      }
    } catch (err) {
      // Detailed error logging to see exactly what the backend doesn't like
      const errorDetail = err.response?.data?.detail;
      const errorMsg = typeof errorDetail === 'object' ? JSON.stringify(errorDetail) : errorDetail;
      alert(`Error: ${errorMsg || err.message}`);
    }
  };

  return (
    <div className="flex h-screen bg-brand-bg text-white font-sans overflow-hidden">
      {/* Branding Section */}
      <div className="hidden lg:flex w-1/2 bg-linear-to-br from-blue-700 to-indigo-900 p-16 flex-col justify-center">
        <h1 className="text-6xl font-black italic tracking-tighter uppercase mb-4">Demand AI</h1>
        <p className="text-xl text-blue-100/70 max-w-md font-medium leading-relaxed">
          Intelligent demand forecasting using advanced statistical models and business intelligence.
        </p>
      </div>

      {/* Form Section */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md bg-brand-card p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl">
          <header className="mb-8 text-center">
            <h2 className="text-3xl font-black">{isRegistering ? 'Create Account' : 'Welcome Back'}</h2>
            <p className="text-slate-500 mt-2 font-medium">Enter your credentials below</p>
          </header>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegistering && (
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest ml-1">Full Name</label>
                <input 
                  type="text" 
                  name="full_name"
                  placeholder="e.g. Prabu"
                  required
                  className="w-full bg-[#1e293b] p-4 rounded-2xl outline-none border border-transparent focus:border-blue-500 transition-all text-sm"
                  onChange={handleChange}
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest ml-1">Email Address</label>
              <input 
                type="email" 
                name="email"
                placeholder="name@company.com"
                required
                className="w-full bg-[#1e293b] p-4 rounded-2xl outline-none border border-transparent focus:border-blue-500 transition-all text-sm"
                onChange={handleChange}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest ml-1">Password</label>
              <input 
                type="password" 
                name="password"
                placeholder="••••••••"
                required
                className="w-full bg-[#1e293b] p-4 rounded-2xl outline-none border border-transparent focus:border-blue-500 transition-all text-sm"
                onChange={handleChange}
              />
            </div>

            <button className="w-full bg-blue-600 hover:bg-blue-500 py-4 rounded-2xl font-black text-lg transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98] mt-4">
              {isRegistering ? 'Get Started' : 'Sign In'}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsRegistering(!isRegistering)}
              className="text-slate-500 font-bold hover:text-blue-500 text-sm transition-colors"
            >
              {isRegistering ? 'Already have an account? Login' : "New user? Create an account"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}