from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
import os
import shutil

router = APIRouter()
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
ACTIVE_FILE = os.path.join(UPLOAD_DIR, "active_dataset.csv")

@router.post("/upload") # Now accessible via /analytics/upload
async def dataset_upload(file: UploadFile = File(...)):
    try:
        with open(ACTIVE_FILE, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        return {"status": "success", "message": "File uploaded"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.get("/monthly-sales")
async def get_monthly_sales():
    if not os.path.exists(ACTIVE_FILE):
        return []
    
    try:
        df = pd.read_csv(ACTIVE_FILE)
        df.columns = df.columns.str.strip()
        
        date_col = next((c for c in df.columns if c.lower() == 'date'), None)
        revenue_col = next((c for c in df.columns if c.lower() == 'revenue'), None)

        if not date_col or not revenue_col:
            return []

        # --- FIX: Added dayfirst=True and errors='coerce' ---
        df[date_col] = pd.to_datetime(df[date_col], dayfirst=True, errors='coerce')
        
        # Drop rows where dates couldn't be parsed
        df = df.dropna(subset=[date_col])
        
        monthly = df.groupby(df[date_col].dt.to_period('M'))[revenue_col].sum().reset_index()
        
        return [
            {"date": str(row[date_col]), "revenue": float(row[revenue_col])} 
            for _, row in monthly.iterrows()
        ]
    except Exception as e:
        print(f"Date Parsing Error: {e}")
        return []

@router.get("/summary")
async def get_summary():
    if not os.path.exists(ACTIVE_FILE):
        return {"total_revenue": 0, "dataset_rows": 0, "top_product": "N/A"}
    
    try:
        df = pd.read_csv(ACTIVE_FILE)
        df.columns = df.columns.str.strip()
        
        # Dynamic Column Finding
        rev_col = next((c for c in df.columns if c.lower() == 'revenue'), None)
        prod_col = next((c for c in df.columns if c.lower() == 'product'), None)

        if rev_col is None:
            return {"total_revenue": 0, "dataset_rows": len(df), "top_product": "Missing Revenue Col"}

        total_rev = int(df[rev_col].sum())
        
        # Robust top product logic
        top_p = "N/A"
        if prod_col and not df.empty:
            top_p = df.groupby(prod_col)[rev_col].sum().idxmax()

        return {
            "total_revenue": total_rev,
            "dataset_rows": len(df),
            "top_product": top_p
        }
    except Exception as e:
        # Prevents the 500 Internal Server Error by returning a 200 with error info
        return {"total_revenue": 0, "dataset_rows": 0, "top_product": f"Error: {str(e)}"}