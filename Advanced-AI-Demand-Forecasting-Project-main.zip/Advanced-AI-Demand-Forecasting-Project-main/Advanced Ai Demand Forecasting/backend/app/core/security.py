from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends
from fastapi.security import OAuth2PasswordBearer

# Constants
SECRET_KEY = "ai-forecasting-secret-key-2026" 
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# --- UPDATED CONTEXT ---
# Adding 'bcrypt' explicitly and setting it as the only scheme
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

class SecurityHandler:
    @staticmethod
    def hash_password(password: str) -> str:
        # Ensure string is encoded and truncated to 72 bytes strictly
        pwd_bytes = password.encode('utf-8')[:72]
        # Return hash of the truncated password
        return pwd_context.hash(pwd_bytes.decode('utf-8'))

    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        if not hashed_password:
            return False
        try:
            # Strictly truncate before passlib touches it
            safe_pwd = plain_password.encode('utf-8')[:72].decode('utf-8')
            return pwd_context.verify(safe_pwd, hashed_password)
        except Exception:
            return False

    @staticmethod
    def create_access_token(data: dict):
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        to_encode.update({"exp": expire})
        return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

    @staticmethod
    def get_current_user(token: str = Depends(oauth2_scheme)):
        credentials_exception = HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            email: str = payload.get("sub")
            if email is None:
                raise credentials_exception
            return email
        except JWTError:
            raise credentials_exception