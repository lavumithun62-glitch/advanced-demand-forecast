🚀 Advanced AI Demand Forecasting System

An enterprise-level AI-powered Demand Forecasting SaaS platform built using FastAPI, React.js, Machine Learning, and MySQL.

📌 Project Overview

The Advanced AI Demand Forecasting System helps businesses predict future product demand using historical sales data and AI forecasting models.

The platform provides:

📈 Demand Forecasting
📊 Analytics Dashboard
🤖 AI Predictions
📂 Dataset Upload & Cleaning
📑 PDF/Excel Reports
🔐 JWT Authentication
🌐 Responsive SaaS Dashboard
🛠️ Tech Stack
⚙️ Backend
⚡ FastAPI
🗄️ MySQL
🧩 SQLAlchemy
🔐 JWT Authentication
🐼 Pandas
🤖 Scikit-learn
📈 Prophet
📦 Pydantic
🎨 Frontend
⚛️ React.js (Vite)
🎨 Tailwind CSS
🔗 Axios
📊 Recharts
🛣️ React Router DOM
✨ Features
🔐 Authentication Module
User Registration
User Login
JWT Token Authentication
Password Encryption
Protected Routes
Session Management
📂 Dataset Upload Module
Upload CSV Files
Upload Excel Files
Dataset Validation
Missing Value Handling
Duplicate Record Removal
Data Cleaning
Dataset Storage
🤖 AI Forecasting Module
Demand Prediction
Linear Regression Forecasting
Prophet Forecasting
Time Series Analysis
Future Sales Prediction
Forecast Accuracy Metrics
Trend Analysis
Multi-product Forecasting
📊 Dashboard & Analytics
Total Sales Analytics
Monthly Sales Trends
Forecast Accuracy
Top Products
Interactive Charts
Forecast Graphs
KPI Cards
📑 Reports Module
Export Excel Reports
Export PDF Reports
Forecast Summary Reports
Downloadable Analytics
📁 Project Structure
advanced-ai-demand-forecasting/
│
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── core/
│   │   ├── models/
│   │   ├── schemas/
│   │   ├── services/
│   │   ├── utils/
│   │   ├── uploads/
│   │   └── main.py
│   │
│   ├── requirements.txt
│   └── .env
│
├── frontend/
│   ├── src/
│   │   ├── api/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── routes/
│   │   ├── App.jsx
│   │   └── main.jsx
│   │
│   ├── package.json
│   └── vite.config.js
│
└── README.md
⚙️ Installation & Setup
🔹 Clone Repository
git clone https://github.com/your-username/advanced-ai-demand-forecasting.git
cd advanced-ai-demand-forecasting
🐍 Backend Setup
📌 Navigate to Backend
cd backend
📌 Create Virtual Environment
Windows
python -m venv venv
📌 Activate Virtual Environment
PowerShell
.\venv\Scripts\Activate.ps1
CMD
venv\Scripts\activate.bat
📌 Install Backend Dependencies
pip install -r requirements.txt
📌 Run Backend Server
uvicorn app.main:app --reload
🌐 Backend URLs
Service	URL
Backend API	http://127.0.0.1:8000
Swagger Docs	http://127.0.0.1:8000/docs
🎨 Frontend Setup
📌 Navigate to Frontend
cd frontend
📌 Install Dependencies
npm install
📌 Run Frontend
npm run dev
🌐 Frontend URL
Service	URL
Frontend App	http://localhost:5173
🗄️ MySQL Database Setup
📌 Create Database
CREATE DATABASE demand_forecasting;
🔑 Environment Variables

Create a .env file inside backend folder.

DATABASE_URL=mysql+pymysql://root:password@localhost/demand_forecasting
SECRET_KEY=supersecretkey
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
📡 API Endpoints
🔐 Authentication APIs
Method	Endpoint	Description
POST	/auth/register	Register User
POST	/auth/login	Login User
📂 Dataset APIs
Method	Endpoint	Description
POST	/dataset/upload	Upload Dataset
GET	/dataset/list	Get Dataset List
🤖 Forecast APIs
Method	Endpoint	Description
POST	/forecast/train	Train Forecast Model
GET	/forecast/predict	Generate Forecast
📊 Dashboard APIs
Method	Endpoint	Description
GET	/dashboard/analytics	Dashboard Analytics
📑 Reports APIs
Method	Endpoint	Description
GET	/reports/export/excel	Export Excel Report
GET	/reports/export/pdf	Export PDF Report
📈 Sample Dataset Format
date,product,sales
2025-01-01,Laptop,120
2025-01-02,Laptop,150
2025-01-03,Mouse,80
2025-01-04,Keyboard,95
📸 Application Modules
🔐 Authentication
Login Page
Register Page
JWT Security
📊 Dashboard
KPI Cards
Forecast Charts
Sales Trends
📂 Dataset Upload
CSV Upload
Excel Upload
Data Cleaning
🤖 Forecasting
Demand Prediction
Forecast Accuracy
Trend Analysis
📑 Reports
PDF Export
Excel Export
🚀 Deployment
🌐 Frontend Deployment
Vercel
Netlify
⚙️ Backend Deployment
Render
Railway
AWS EC2
🗄️ Database Hosting
PlanetScale
Railway MySQL
AWS RDS
🧠 Future Enhancements
🔥 LSTM Forecasting
☁️ Cloud Storage
📧 Email Reports
📱 Mobile App
🤖 AI Chatbot Assistant
📊 Real-time Analytics
🔔 Notification System
👥 Role-based Access
💳 Subscription Billing
🧪 Testing Workflow
Register User
Login User
Upload Dataset
Train Forecast Model
Generate Predictions
View Dashboard Analytics
Export Reports

👨‍💻 Developer

Built for enterprise-level AI forecasting and analytics applications.

⭐ Final Result

✅ Full-stack AI SaaS Platform
✅ FastAPI + React Integration
✅ AI Forecasting System
✅ JWT Authentication
✅ Interactive Dashboard
✅ PDF & Excel Reports
✅ Production-ready Architecture
✅ Responsive Tailwind UI



👨‍💻 Author

Prabu Ram
