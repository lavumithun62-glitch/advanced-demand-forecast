from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from app.api.deps import get_current_user
import pandas as pd
import io

router = APIRouter()

@router.post("/upload")
async def upload_dataset(
    file: UploadFile = File(...), 
    current_user=Depends(get_current_user)
):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are allowed")
    
    # Read CSV to verify it
    contents = await file.read()
    df = pd.read_csv(io.StringIO(contents.decode('utf-8')))
    
    # Logic to save file locally or to DB
    # df.to_csv(f"uploads/{current_user}_data.csv")
    
    return {
        "filename": file.filename, 
        "rows": len(df), 
        "columns": list(df.columns),
        "message": "Dataset uploaded successfully"
    }