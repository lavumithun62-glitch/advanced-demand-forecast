import React, { useState } from 'react';
import axios from 'axios';
import { 
  FileText, 
  Table, 
  Download, 
  Clock, 
  ChevronRight,
  FileCheck,
  Activity
} from 'lucide-react';

export default function Reports() {
  const [loading, setLoading] = useState({ csv: false, pdf: false });

  const handleDownload = async (type) => {
    setLoading({ ...loading, [type]: true });
    try {
      const response = await axios({
        url: `http://127.0.0.1:8000/reports/export-${type}`,
        method: 'GET',
        responseType: 'blob', // Necessary for downloading files
      });

      // Create a temporary link to trigger the browser download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Demand_Report_${new Date().toLocaleDateString()}.${type}`);
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Export failed:", err);
      alert(`Export Failed: Ensure the backend server is running and the dataset is uploaded.`);
    } finally {
      setLoading({ ...loading, [type]: false });
    }
  };

  const reportCards = [
    {
      id: 'pdf',
      title: 'Executive PDF Summary',
      desc: 'Includes AI trend visualizations, Prophet model metrics, and business insights for stakeholders.',
      icon: <FileText className="text-blue-500" size={32} />,
      btnColor: 'bg-blue-600 hover:bg-blue-500',
      shadow: 'shadow-blue-600/20'
    },
    {
      id: 'csv',
      title: 'Raw Forecast Data (CSV)',
      desc: 'Detailed monthly prediction rows and accuracy error percentages for external Excel analysis.',
      icon: <Table className="text-emerald-500" size={32} />,
      btnColor: 'bg-emerald-600 hover:bg-emerald-500',
      shadow: 'shadow-emerald-600/20'
    }
  ];

  return (
    <div className="p-10 ml-64 bg-[#030712] min-h-screen text-white font-sans">
      {/* Header Section */}
      <header className="mb-12">
        <h1 className="text-4xl font-black tracking-tighter">Reports & Analytics</h1>
        <p className="text-slate-500 mt-2 font-medium">Export generated AI intelligence into professional formats.</p>
      </header>

      {/* Main Export Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {reportCards.map((card) => (
          <div key={card.id} className="bg-[#0b1120] border border-slate-800 rounded-[2.5rem] p-10 flex flex-col justify-between transition-all hover:border-slate-700 shadow-2xl">
            <div>
              <div className="bg-slate-900/50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 border border-slate-800">
                {card.icon}
              </div>
              <h2 className="text-2xl font-black mb-3">{card.title}</h2>
              <p className="text-slate-500 text-sm leading-relaxed mb-10">{card.desc}</p>
            </div>

            <button 
              onClick={() => handleDownload(card.id)}
              disabled={loading[card.id]}
              className={`w-full ${card.btnColor} ${card.shadow} py-4 rounded-2xl font-black flex items-center justify-center gap-3 transition-all shadow-lg active:scale-[0.98] disabled:opacity-50`}
            >
              {loading[card.id] ? (
                <Activity className="animate-spin" size={20} />
              ) : (
                <Download size={20} />
              )}
              {loading[card.id] ? 'GENERATING...' : `DOWNLOAD ${card.id.toUpperCase()}`}
            </button>
          </div>
        ))}
      </div>

      {/* History Log Section */}
      <div className="bg-[#0b1120] border border-slate-800 rounded-[2.5rem] overflow-hidden">
        <div className="p-8 border-b border-slate-800 flex justify-between items-center">
          <h3 className="font-bold flex items-center gap-2 text-slate-300 uppercase text-xs tracking-widest">
            <Clock size={16} className="text-blue-500" /> Recent Activity Log
          </h3>
          <span className="text-[10px] bg-slate-800 text-slate-500 px-3 py-1 rounded-full font-black">LIVE UPDATES</span>
        </div>
        
        <table className="w-full text-left">
          <thead className="bg-[#0f172a] text-[10px] text-slate-500 font-black uppercase tracking-[0.2em]">
            <tr>
              <th className="p-6">Timestamp</th>
              <th className="p-6">Report Action</th>
              <th className="p-6 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            <tr className="hover:bg-blue-500/5 transition-colors">
              <td className="p-6 text-sm text-slate-400">May 13, 2026 • 12:45 PM</td>
              <td className="p-6">
                <div className="flex items-center gap-2">
                  <FileCheck size={14} className="text-emerald-500" />
                  <span className="text-sm font-bold text-slate-300">CSV Data Exported</span>
                </div>
              </td>
              <td className="p-6 text-right">
                <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full">SUCCESS</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}