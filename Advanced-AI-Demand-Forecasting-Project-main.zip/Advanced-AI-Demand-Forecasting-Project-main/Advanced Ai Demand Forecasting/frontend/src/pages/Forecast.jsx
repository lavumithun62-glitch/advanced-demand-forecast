import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { 
  Cpu, Activity, Calendar, BarChart3, Filter, BrainCircuit, TrendingUp 
} from 'lucide-react';

export default function Forecast() {
  const [data, setData] = useState([]);
  const [summary, setSummary] = useState({ error: "0%", model: "Prophet", months: 6 });

  const runForecast = async () => {
    try {
      const res = await axios.get('http://127.0.0.1:8000/forecast/predict');
      // Formatting backend data for the Line Chart
      const chartFormatted = res.data.data.map(item => ({
        name: item.month,
        revenue: parseFloat(item.predicted_revenue.replace(/[₹,]/g, ''))
      }));
      setData(chartFormatted);
      setSummary({ error: res.data.data[0].prediction_error, model: "Prophet Forecasting", months: 6 });
    } catch (err) {
      console.error("Forecast failed");
    }
  };

  const cards = [
    { title: 'AI Model', value: summary.model, color: 'bg-gradient-to-r from-cyan-400 to-blue-500', icon: BrainCircuit },
    { title: 'Forecast Error', value: summary.error, color: 'bg-gradient-to-r from-orange-500 to-red-500', icon: Activity },
    { title: 'Forecast Months', value: summary.months, color: 'bg-gradient-to-r from-purple-500 to-pink-500', icon: TrendingUp },
    { title: 'Prediction Status', value: 'Active', color: 'bg-gradient-to-r from-emerald-400 to-green-500', icon: BarChart3 },
  ];

  return (
    <div className="p-8 ml-64 bg-brand-bg min-h-screen text-white font-sans">
      {/* Title Section */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold tracking-tight">AI Forecast Intelligence</h1>
        <p className="text-slate-400 mt-1">Advanced Prophet-based business demand forecasting system</p>
      </div>

      {/* Filter Bar (Matches the gray rounded bar in image) */}
      <div className="bg-brand-card p-6 rounded-2xl border border-slate-800 flex flex-wrap gap-4 items-center mb-8 shadow-lg">
        <div className="flex items-center gap-2 mr-4 text-slate-400 font-bold uppercase text-xs">
          <Filter size={16} /> Forecast Filters
        </div>
        <input className="bg-[#1e293b] p-3 rounded-lg flex-1 outline-none text-sm border border-slate-700" placeholder="Category (Technology)" />
        <input className="bg-[#1e293b] p-3 rounded-lg flex-1 outline-none text-sm border border-slate-700" placeholder="Product (Chair)" />
        <select className="bg-[#1e293b] p-3 rounded-lg outline-none text-sm border border-slate-700 text-slate-400">
          <option>6 Months</option>
          <option>12 Months</option>
        </select>
        <button 
          onClick={runForecast}
          className="bg-blue-600 hover:bg-blue-500 px-10 py-3 rounded-lg font-bold text-sm transition-all"
        >
          Generate Forecast
        </button>
      </div>

      {/* Metric Cards Section (Prophet, Error, Months, Status) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {cards.map((c, i) => (
          <div key={i} className={`${c.color} p-6 rounded-3xl relative overflow-hidden h-32 flex flex-col justify-end shadow-lg`}>
            <div className="absolute top-4 right-4 bg-white/20 p-2 rounded-xl backdrop-blur-md">
              <c.icon size={24} className="text-white" />
            </div>
            <p className="text-[10px] font-bold uppercase opacity-80 mb-1">{c.title}</p>
            <h2 className="text-xl font-black">{c.value}</h2>
          </div>
        ))}
      </div>

      {/* Large Chart Section */}
      <div className="bg-brand-card p-8 rounded-3xl border border-slate-800 shadow-2xl">
        <div className="mb-6">
          <h3 className="text-2xl font-bold">Future Revenue Prediction</h3>
          <p className="text-slate-500 text-sm mt-1">AI-generated forecast trend analysis using Prophet forecasting</p>
        </div>

        <div className="h-100 w-full mt-10">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#475569', fontSize: 12}} 
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#475569', fontSize: 12}} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '12px' }}
                itemStyle={{ color: '#10b981' }}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="#10b981" 
                strokeWidth={4} 
                dot={{ fill: '#10b981', r: 6, strokeWidth: 2, stroke: '#0b1120' }}
                activeDot={{ r: 8, strokeWidth: 0 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}