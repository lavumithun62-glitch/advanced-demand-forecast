class Settings:
    PROJECT_NAME: str = "AI Demand Forecasting"
    SECRET_KEY: str = "YOUR_SUPER_SECRET_KEY_12345" # Change this!
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

settings = Settings()