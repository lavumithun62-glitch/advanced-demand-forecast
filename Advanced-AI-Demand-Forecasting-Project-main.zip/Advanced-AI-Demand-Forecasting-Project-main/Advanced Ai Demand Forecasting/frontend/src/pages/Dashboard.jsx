import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { LayoutGrid, TrendingUp, Package, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const [stats, setStats] = useState({ total_revenue: 0, dataset_rows: 0, top_product: '...' });
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    // 1. Get stats for the top cards
    axios.get('http://127.0.0.1:8000/analytics/summary')
      .then(res => setStats(res.data))
      .catch(() => console.log("Stats fetch failed"));

    // 2. Get the actual forecast data for the chart
    axios.get('http://127.0.0.1:8000/forecast/predict')
      .then(res => {
        // Clean the data: remove '₹' and commas so Recharts can read the numbers
        const cleanedData = res.data.data.map(item => ({
          month: item.month,
          revenue: parseFloat(item.predicted_revenue.replace(/[₹,]/g, ''))
        }));
        setChartData(cleanedData);
      })
      .catch(() => {
        // Fallback data so the chart isn't empty during testing
        setChartData([
          { month: '2024-01', revenue: 4000 },
          { month: '2024-02', revenue: 5500 },
          { month: '2024-03', revenue: 4800 },
          { month: '2024-04', revenue: 7000 }
        ]);
      });
  }, []);

  const cards = [
    { title: 'Total Revenue', value: `₹ ${stats.total_revenue.toLocaleString()}`, color: 'from-blue-600 to-cyan-500', icon: LayoutGrid },
    { title: 'Dataset Rows', value: stats.dataset_rows, color: 'from-purple-600 to-pink-500', icon: Package },
    { title: 'Top Performing', value: stats.top_product, color: 'from-emerald-600 to-teal-500', icon: TrendingUp },
  ];

  return (
    <div className="p-8 ml-64 bg-brand-bg min-h-screen text-white">
      <h1 className="text-3xl font-black mb-8">AI Analytics Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {cards.map((c, i) => (
          <div key={i} className={`bg-linear-to-br ${c.color} p-8 rounded-3xl shadow-xl relative overflow-hidden`}>
            <div className="absolute top-0 right-0 p-4 opacity-10"><c.icon size={80}/></div>
            <p className="text-xs uppercase font-bold tracking-widest opacity-80 mb-2">{c.title}</p>
            <h2 className="text-3xl font-black">{c.value}</h2>
          </div>
        ))}
      </div>

      {/* Revenue Growth Trend Chart */}
      <div className="bg-brand-card p-8 rounded-4xl border border-slate-800 shadow-2xl">
        <div className="flex justify-between items-center mb-10">
          <h3 className="font-bold text-slate-400 uppercase text-xs tracking-widest flex items-center gap-2">
            <Activity size={16} className="text-blue-500" /> Revenue Growth Trend
          </h3>
          <div className="flex gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500 shadow-[0_0_8px_#3b82f6]"></span>
            <span className="text-[10px] text-slate-500 font-bold uppercase">Live Forecast</span>
          </div>
        </div>
        
        <div className="h-100 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis 
                dataKey="month" 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#64748b', fontSize: 12, fontWeight: 'bold'}} 
                dy={15}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#64748b', fontSize: 12, fontWeight: 'bold'}} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '16px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.5)' }}
                itemStyle={{ color: '#3b82f6', fontWeight: 'bold' }}
                cursor={{ stroke: '#3b82f6', strokeWidth: 2 }}
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stroke="#3b82f6" 
                strokeWidth={4}
                fillOpacity={1} 
                fill="url(#colorRev)" 
                animationDuration={2000}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}