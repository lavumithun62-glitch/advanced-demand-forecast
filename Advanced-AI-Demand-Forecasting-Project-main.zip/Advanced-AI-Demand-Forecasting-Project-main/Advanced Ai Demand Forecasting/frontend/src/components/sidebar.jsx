import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutGrid, UploadCloud, TrendingUp, BarChart3, LogOut } from 'lucide-react';

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();

  const menu = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutGrid },
    { name: 'Upload Dataset', path: '/dataset', icon: UploadCloud },
    { name: 'Forecast', path: '/forecast', icon: TrendingUp },
    { name: 'Reports', path: '/reports', icon: BarChart3 },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <aside className="w-64 fixed inset-y-0 bg-[#0b0e14] border-r border-slate-800 flex flex-col p-4 z-50">
      <div className="mb-10 px-4">
        <h1 className="text-white text-xl font-bold">AI Forecast</h1>
        <p className="text-slate-500 text-[10px] uppercase tracking-widest">Demand Platform</p>
      </div>

      <nav className="flex-1 space-y-1">
        {menu.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              location.pathname === item.path 
              ? 'bg-[#1e293b] text-blue-500 border-r-2 border-blue-500' 
              : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
            }`}
          >
            <item.icon size={18} /> {item.name}
          </Link>
        ))}
      </nav>

      <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-400 text-sm font-medium transition-colors bg-[#1a1114] rounded-lg mt-auto">
        <LogOut size={18} /> Logout
      </button>
    </aside>
  );
}