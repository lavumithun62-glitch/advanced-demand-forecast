from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
import os
import shutil

router = APIRouter()

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
ACTIVE_DATASET = os.path.join(UPLOAD_DIR, "active_data.csv")

@router.post("/upload")
async def upload_dataset(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a CSV.")
    
    try:
        # Save temporary file to process with Pandas
        with open("temp.csv", "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # --- PREVIOUS WORK: Data Cleaning ---
        df = pd.read_csv("temp.csv")
        df = df.fillna(method='ffill') # Handle missing values
        df = df.drop_duplicates()      # Handle duplicates
        
        # Save the "Cleaned" version for the AI module
        df.to_csv(ACTIVE_DATASET, index=False)
        os.remove("temp.csv")

        return {
            "status": "success", 
            "message": "Dataset cleaned and activated.",
            "rows": len(df)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing Error: {str(e)}")