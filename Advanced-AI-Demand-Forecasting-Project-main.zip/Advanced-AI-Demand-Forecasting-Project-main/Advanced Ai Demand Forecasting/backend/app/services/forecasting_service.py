import pandas as pd
from prophet import Prophet
import io

def run_prophet_forecast(csv_content):
    # 1. Load data
    df = pd.read_csv(io.BytesIO(csv_content))
    
    # 2. Prepare for Prophet (Requires columns 'ds' and 'y')
    df = df.rename(columns={'date': 'ds', 'sales': 'y'})
    df['ds'] = pd.to_datetime(df['ds'])
    
    # 3. Initialize and Fit Model
    model = Prophet(yearly_seasonality=True, interval_width=0.95)
    model.fit(df)
    
    # 4. Create Future Dates (6 Months)
    future = model.make_future_dataframe(periods=6, freq='MS')
    forecast = model.predict(future)
    
    # 5. Format results for Frontend
    # We only want the future predictions (where 'ds' > last date in original data)
    last_date = df['ds'].max()
    predictions = forecast[forecast['ds'] > last_date]
    
    results = []
    for _, row in predictions.iterrows():
        results.append({
            "month": row['ds'].strftime('%Y-%m'),
            "revenue": round(row['yhat'], 2),
            "status": "Predicted"
        })
        
    return {
        "model": "Prophet",
        "mape": "32.72%", # Static example matching your screenshot
        "predictions": results
    }