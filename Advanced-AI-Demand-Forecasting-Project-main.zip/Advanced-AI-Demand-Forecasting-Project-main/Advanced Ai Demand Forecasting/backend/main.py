import os
import shutil
import pandas as pd
import bcrypt
from fastapi import FastAPI, UploadFile, File, HTTPException, APIRouter, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from jose import jwt
from datetime import datetime, timedelta
from prophet import Prophet
from fpdf import FPDF

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- CONFIG & STORAGE ---
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
ACTIVE_FILE = os.path.join(UPLOAD_DIR, "active_dataset.csv")
SECRET_KEY = "demand_ai_secret"
users_db = {} 

# --- AUTH LOGIC ---
class AuthModel(BaseModel):
    email: str
    password: str

def get_pw_hash(password: str):
    return bcrypt.hashpw(password.encode('utf-8')[:72], bcrypt.gensalt()).decode('utf-8')

@app.post("/auth/register")
async def register(user: AuthModel):
    users_db[user.email] = get_pw_hash(user.password)
    return {"message": "User registered"}

@app.post("/auth/login")
async def login(user: AuthModel):
    if user.email not in users_db or not bcrypt.checkpw(user.password.encode('utf-8')[:72], users_db[user.email].encode('utf-8')):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = jwt.encode({"sub": user.email, "exp": datetime.utcnow() + timedelta(hours=24)}, SECRET_KEY)
    return {"access_token": token}

# --- DATASET & ANALYTICS ---
@app.post("/analytics/upload")
async def upload(file: UploadFile = File(...)):
    with open(ACTIVE_FILE, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"status": "success"}

@app.get("/analytics/summary")
async def summary():
    if not os.path.exists(ACTIVE_FILE): return {"total_revenue": 0, "dataset_rows": 0, "top_product": "N/A"}
    df = pd.read_csv(ACTIVE_FILE)
    df.columns = df.columns.str.strip()
    rev_col = next((c for c in df.columns if 'revenue' in c.lower()), df.columns[-1])
    prod_col = next((c for c in df.columns if 'product' in c.lower()), df.columns[0])
    return {
        "total_revenue": int(df[rev_col].sum()),
        "dataset_rows": len(df),
        "top_product": str(df.groupby(prod_col)[rev_col].sum().idxmax())
    }

# --- AI FORECASTING (PROPHET) ---
@app.get("/forecast/predict")
async def predict():
    df = pd.read_csv(ACTIVE_FILE)
    df.columns = df.columns.str.strip()
    date_col = next((c for c in df.columns if 'date' in c.lower()), None)
    rev_col = next((c for c in df.columns if 'revenue' in c.lower()), None)
    
    df[date_col] = pd.to_datetime(df[date_col], dayfirst=True, errors='coerce', format='mixed')
    df = df.dropna(subset=[date_col]).rename(columns={date_col: 'ds', rev_col: 'y'})
    
    model = Prophet().fit(df[['ds', 'y']])
    future = model.make_future_dataframe(periods=6, freq='MS')
    forecast = model.predict(future)
    
    res = forecast[['ds', 'yhat']].tail(6)
    return {"data": [{"month": r['ds'].strftime('%Y-%m'), "predicted_revenue": round(r['yhat'], 2)} for _, r in res.iterrows()]}

# --- REPORTS ---
@app.get("/reports/export-pdf")
async def export_pdf():
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(190, 10, "Demand Forecast Intelligence Report", ln=True, align='C')
    pdf.output("uploads/report.pdf")
    return FileResponse("uploads/report.pdf", filename="AI_Report.pdf")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)